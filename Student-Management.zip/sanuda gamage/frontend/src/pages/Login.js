import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from "react-router-dom";

const Login = () => {
    const [credentials, setCredentials] = useState({ username: '', password: '' });
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCredentials({ ...credentials, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/api/users/login', credentials);
            localStorage.setItem('token', response.data.token);
            alert('Login successful!');
            navigate('/dashboard');
        } catch (error) {
            alert('Invalid credentials.');
        }
    };

    const handleGoogleLogin = () => {
        window.location.href = 'http://localhost:5000/api/users/auth/google';
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4">Login</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Username</label>
                    <input
                        type="text"
                        className="form-control"
                        name="username"
                        value={credentials.username}
                        onChange={handleChange}
                        placeholder="Enter User name"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                        type="password"
                        className="form-control"
                        name="password"
                        value={credentials.password}
                        onChange={handleChange}
                        placeholder='Enter Email'
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary">
                    Login
                </button>
                <button type="button" className="btn btn-danger ms-2" onClick={handleGoogleLogin}>
                    Login with Google
                </button>
            </form>
            <br></br><br></br>
            <h4>"Don't have an account? Sign up now to access exclusive features and stay connected!"</h4>
            
            <Link to="/register-admin" className="btn btn-primary">
                Create Account
            </Link>
        </div>
    );
};

export default Login;
