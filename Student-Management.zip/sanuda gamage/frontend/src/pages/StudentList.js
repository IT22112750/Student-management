import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";

const StudentList = () => {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5000/api/students")
            .then((res) => res.json())
            .then((data) => setStudents(data));
    }, []);

    return (
        <Container className="mt-4">
            <h2>Student List</h2>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {students.map((student) => (
                        <tr key={student._id}>
                            <td>{student.name}</td>
                            <td>{student.status === "Active" ? "Active" : "Inactive"}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </Container>
    );
};

export default StudentList;
