import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

const AddStudent = () => {
    const [student, setStudent] = useState({
        name: "",
        age: "",
        status: "Active",
        image: ""
    });

    const [imagePreview, setImagePreview] = useState(null);
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        setStudent({ ...student, [e.target.name]: e.target.value });
    };

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", "your_upload_preset"); // Change this to your Cloudinary preset

        try {
            const response = await axios.post(
                "https://api.cloudinary.com/v1_1/your_cloud_name/image/upload", 
                formData
            );

            setStudent({ ...student, image: response.data.secure_url });
            setImagePreview(response.data.secure_url);
        } catch (error) {
            console.error("Image upload failed:", error);
        }
    };

    const validate = () => {
        const errors = {};
        if (!student.name) {
            errors.name = "Name is required";
        } else if (!/^[A-Za-z\s]+$/.test(student.name)) {
            errors.name = "Name can only contain letters";
        }
        if (!student.age) errors.age = "Age is required";
        if (student.age && (student.age < 1 || student.age > 100)) errors.age = "Age must be between 1 and 100";
        return errors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const errors = validate();
        if (Object.keys(errors).length > 0) {
            setErrors(errors);
            return;
        }
        try {
            const response = await fetch("http://localhost:5000/api/students", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(student),
            });

            if (response.ok) {
                alert("Student added successfully!");
                navigate("/students");
            } else {
                alert("Error adding student.");
            }
        } catch (error) {
            console.error("Failed to add student:", error);
            alert("Failed to add student.");
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4">Add Student</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={student.name}
                        onChange={handleChange}
                        placeholder="Enter name"
                        required
                    />
                    {errors.name && <div className="text-danger">{errors.name}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Age</label>
                    <input
                        type="number"
                        className="form-control"
                        name="age"
                        value={student.age}
                        onChange={handleChange}
                        placeholder="Enter Age"
                        required
                    />
                    {errors.age && <div className="text-danger">{errors.age}</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Upload Image</label>
                    <input type="file" className="form-control" onChange={handleImageUpload} accept="image/*" />
                </div>

                {imagePreview && (
                    <div className="mb-3">
                        <img src={imagePreview} alt="Preview" className="img-thumbnail" width="150" />
                    </div>
                )}

                <div className="mb-3">
                    <label className="form-label">Status</label>
                    <select
                        className="form-select"
                        name="status"
                        value={student.status}
                        onChange={handleChange}
                    >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>

                <button type="submit" className="btn btn-primary">
                    Submit
                </button>
            </form>
        </div>
    );
};

export default AddStudent;