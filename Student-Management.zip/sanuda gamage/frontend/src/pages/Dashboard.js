import React, { useEffect, useState } from "react";
import { Container, Table, Button } from "react-bootstrap";
import EditStudentModal from "../components/EditStudentModal";
import axios from 'axios';

const Dashboard = () => {
    const [students, setStudents] = useState([]);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        fetch("http://localhost:5000/api/students")
            .then((res) => res.json())
            .then((data) => setStudents(data));
    }, []);

    const handleEdit = (student) => {
        setSelectedStudent(student);
        setShowModal(true);
    };

    const handleSave = (updatedStudent) => {
        setStudents(students.map(student => student._id === updatedStudent._id ? updatedStudent : student));
    };

    const handleDelete = async (studentId) => {
        try {
            await axios.delete(`http://localhost:5000/api/students/${studentId}`);
            setStudents(students.filter(student => student._id !== studentId));
            alert('Student deleted successfully!');
        } catch (error) {
            console.error('Error deleting student:', error);
            alert('Error deleting student.');
        }
    };

    return (
        <Container className="mt-4">
            <h1>Admin Dashboard</h1>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {students.map((student) => (
                        <tr key={student._id}>
                            <td>{student.name}</td>
                            <td>{student.age}</td>
                            <td>
                                {student.image && (
                                    <img src={student.image} alt={student.name} style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '50%' }} />
                                )}
                            </td>
                            <td>{student.status}</td>
                            <td>
                                <Button variant="warning" onClick={() => handleEdit(student)}>
                                    Edit
                                </Button>
                                <Button variant="danger" onClick={() => handleDelete(student._id)} className="ms-2">
                                    Delete
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            {selectedStudent && (
                <EditStudentModal
                    show={showModal}
                    handleClose={() => setShowModal(false)}
                    student={selectedStudent}
                    onSave={handleSave}
                />
            )}
        </Container>
    );
};

export default Dashboard;
