import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import axios from 'axios';

const EditStudentModal = ({ show, handleClose, student, onSave }) => {
    const [updatedStudent, setUpdatedStudent] = useState(student);
    const [errors, setErrors] = useState({});

    useEffect(() => {
        setUpdatedStudent(student);
    }, [student]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUpdatedStudent({ ...updatedStudent, [name]: value });
    };

    const validate = () => {
        const errors = {};
        if (!updatedStudent.name) {
            errors.name = "Name is required";
        } else if (!/^[A-Za-z\s]+$/.test(updatedStudent.name)) {
            errors.name = "Name can only contain letters";
        }
        if (!updatedStudent.age) errors.age = "Age is required";
        if (updatedStudent.age && (updatedStudent.age < 1 || updatedStudent.age > 100)) errors.age = "Age must be between 1 and 100";
        return errors;
    };

    const handleSave = async () => {
        const errors = validate();
        if (Object.keys(errors).length > 0) {
            setErrors(errors);
            return;
        }
        try {
            const response = await axios.put(`http://localhost:5000/api/students/${student._id}`, updatedStudent);
            onSave(response.data);
            handleClose();
        } catch (error) {
            console.error('Error updating student:', error);
            alert('Error updating student.');
        }
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Edit Student</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group className="mb-3">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={updatedStudent.name}
                            onChange={handleChange}
                        />
                        {errors.name && <div className="text-danger">{errors.name}</div>}
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Age</Form.Label>
                        <Form.Control
                            type="number"
                            name="age"
                            value={updatedStudent.age}
                            onChange={handleChange}
                        />
                        {errors.age && <div className="text-danger">{errors.age}</div>}
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Status</Form.Label>
                        <Form.Select
                            name="status"
                            value={updatedStudent.status}
                            onChange={handleChange}
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </Form.Select>
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
                <Button variant="primary" onClick={handleSave}>
                    Save Changes
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default EditStudentModal;
